const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const config = require('../config');
const { generalLimiter } = require('./middleware/rate-limit');
const Session = require('./models/session');
const LoginAttempt = require('./models/login-attempt');

// Routes
const authRoutes = require('./routes/auth');
const inviteRoutes = require('./routes/invites');
const healthRoutes = require('./routes/health');

const app = express();

// ---- Security middlewares ----
app.use(helmet());
app.use(cors({
  origin: config.corsOrigins,
  credentials: true,
}));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(generalLimiter);

// Trust proxy (for rate limiting behind reverse proxy / Nginx)
app.set('trust proxy', 1);

// ---- Request logging (dev) ----
if (config.nodeEnv === 'development') {
  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      const ms = Date.now() - start;
      console.log(`${req.method} ${req.path} ${res.statusCode} ${ms}ms`);
    });
    next();
  });
}

// ---- Routes ----
app.use('/api/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/invites', inviteRoutes);

// ---- 404 handler ----
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// ---- Global error handler ----
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// ---- Periodic cleanup ----
setInterval(async () => {
  try {
    const sessions = await Session.cleanup();
    const attempts = await LoginAttempt.cleanup();
    if (sessions > 0 || attempts > 0) {
      console.log(`🧹 Cleanup: ${sessions} expired sessions, ${attempts} old login attempts`);
    }
  } catch (err) {
    console.error('Cleanup error:', err.message);
  }
}, 3600000); // every hour

// ---- Start ----
app.listen(config.port, () => {
  console.log('');
  console.log(`🚀 Volume Alert Server running on port ${config.port}`);
  console.log(`   Environment: ${config.nodeEnv}`);
  console.log(`   CORS origins: ${config.corsOrigins.join(', ')}`);
  console.log('');
  console.log('   Endpoints:');
  console.log('   GET  /api/health           — Server status');
  console.log('   POST /api/auth/register    — Register (requires invite)');
  console.log('   POST /api/auth/login       — Login');
  console.log('   POST /api/auth/logout      — Logout');
  console.log('   POST /api/auth/logout-all  — Logout everywhere');
  console.log('   GET  /api/auth/me          — Current user');
  console.log('   POST /api/auth/change-password — Change password');
  console.log('   POST /api/invites          — Create invite');
  console.log('   GET  /api/invites          — List my invites');
  console.log('   GET  /api/invites/validate/:code — Validate invite');
  console.log('   DELETE /api/invites/:id     — Revoke invite');
  console.log('');
});

module.exports = app; // export for testing
