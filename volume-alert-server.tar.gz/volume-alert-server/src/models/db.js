const { Pool } = require('pg');
const config = require('../../config');

const pool = new Pool({
  host: config.db.host,
  port: config.db.port,
  database: config.db.database,
  user: config.db.user,
  password: config.db.password,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('❌ Unexpected database pool error:', err.message);
});

// Convenience: run a query
async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  const duration = Date.now() - start;
  if (duration > 1000) {
    console.warn(`⚠ Slow query (${duration}ms):`, text.slice(0, 80));
  }
  return res;
}

// Convenience: get a client for transactions
async function getClient() {
  return pool.connect();
}

module.exports = { pool, query, getClient };
