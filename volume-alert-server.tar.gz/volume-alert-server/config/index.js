const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });

const requiredVars = ['JWT_SECRET', 'DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'];
for (const v of requiredVars) {
  if (!process.env[v] || process.env[v].startsWith('CHANGE_ME')) {
    console.error(`❌ Missing or default env var: ${v}. Check your .env file.`);
    process.exit(1);
  }
}

module.exports = {
  port: parseInt(process.env.PORT) || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',

  db: {
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
  },

  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  },

  bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS) || 12,

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  },

  authRateLimit: {
    windowMs: parseInt(process.env.AUTH_RATE_LIMIT_WINDOW_MS) || 900000,
    max: parseInt(process.env.AUTH_RATE_LIMIT_MAX_REQUESTS) || 10,
  },

  invite: {
    expiryHours: parseInt(process.env.INVITE_EXPIRY_HOURS) || 72,
    maxUses: parseInt(process.env.INVITE_MAX_USES) || 1,
  },

  corsOrigins: (process.env.CORS_ORIGINS || 'http://localhost:3000').split(',').map(s => s.trim()),
};
